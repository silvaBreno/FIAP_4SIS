//
//  Enfermeira.swift
//  ExercicioEnfermeira
//
//  Created by Usuário Convidado on 18/03/24.
//

import Cocoa

class Enfermeira: NSObject {
    
    var nome : String
    var altura : Float
    var graduado : Bool
    var idade : Int
    
    override init(){
        self.nome = ""
        self.idade = 0
        self.altura = 0
        self.graduado = false
    }
    
    init(nome: String, altura: Float, graduado: Bool, idade: Int) {
        self.nome = nome
        self.altura = altura
        self.graduado = graduado
        self.idade = idade
    }
    
    func exibirNomeEnfermeira()-> String{
        return "A(o) enfermeira(o) é: " + self.nome
    }
    
    func jaSeFormou(){
        if(graduado == true){
            print("A(o) enfermeira(o) \(self.nome) já se formou")
        } else {
            print("A(o) enfermeira(o) \(self.nome) não se formou")
        }
    }
    
    func exibirIdade()-> String{
        return "A(o) enfermeira(o) tem: \(self.idade) anos"
    }
    
    func exibirAltura()-> String{
        return "A(o) enfermeira(o) tem: " + String(self.altura) + " metros"
    }
}
