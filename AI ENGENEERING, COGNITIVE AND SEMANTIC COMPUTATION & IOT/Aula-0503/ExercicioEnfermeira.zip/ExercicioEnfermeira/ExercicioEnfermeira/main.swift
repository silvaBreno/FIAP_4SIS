//
//  main.swift
//  ExercicioEnfermeira
//
//  Created by Usuário Convidado on 18/03/24.
//

import Foundation

print("Hello, World!")

var enfermeira = Enfermeira()
//get
enfermeira.nome = "Isabela"
enfermeira.idade = 29
enfermeira.altura = 1.75
enfermeira.graduado = true
//set
print(enfermeira.exibirNomeEnfermeira())
print(enfermeira.exibirIdade())
print(enfermeira.exibirAltura())
print(enfermeira.jaSeFormou())


