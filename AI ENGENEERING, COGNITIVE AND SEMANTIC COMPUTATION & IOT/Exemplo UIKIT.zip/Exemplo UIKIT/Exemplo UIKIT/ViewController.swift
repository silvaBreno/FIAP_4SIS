//
//  ViewController.swift
//  Exemplo UIKIT
//
//  Created by Usuário Convidado on 15/04/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblTipo: UILabel!
    @IBOutlet weak var lblIdade: UILabel!
    @IBOutlet weak var stpIdade: UIStepper!
    @IBOutlet weak var lblPas: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func mudarValorSliderPAS(_ sender: UISlider) {
        lblPas.text = "\(Int(sender.value))"
    }
    
    @IBAction func mudarValorIdade(_ sender: Any) {
        lblIdade.text = "\(stpIdade.value)"
    }
    
    @IBAction func receberLink(_ sender: Any) {
        let alerta = UIAlertController(
            title: "Forma para receber seu exame",
            message: "Faça sua escolha",
            preferredStyle: UIAlertController.Style.actionSheet)
        
        alerta.addAction(UIAlertAction(
            title: "SMS",
            style: UIAlertAction.Style.default,
            handler: { action in
                self.lblTipo.text = action.title
            }))
        
        alerta.addAction(UIAlertAction(
            title: "E-mail",
            style: UIAlertAction.Style.default,
            handler: { action in
                self.lblTipo.text = action.title
            }))
        
        alerta.addAction(UIAlertAction(
            title: "Cancelar",
            style: UIAlertAction.Style.cancel,
            handler: nil))
        
        present(alerta, animated: true )
    }
    
}

