//
//  ViewController.swift
//  Exemplo2TableView
//
//  Created by Usuário Convidado on 12/08/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

