//
//  Aviso.swift
//  Exemplo2TableView
//
//  Created by Usuário Convidado on 12/08/24.
//

import UIKit

class Aviso: NSObject {
    
    static func exibirAviso(msg: String ,sender:UIViewController){
        let alerta = UIAlertController(
            title: "Aviso",
            message: msg,
            preferredStyle: UIAlertController.Style.alert)
        
        alerta.addAction(UIAlertAction(
            title: "Ok",
            style: UIAlertAction.Style.default))
        
        sender.present(alerta, animated: true)
    }
}
