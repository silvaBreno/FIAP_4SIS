//
//  ViewController.swift
//  Correção Fixação
//
//  Created by Usuário Convidado on 26/08/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imgFigura: UIImageView!
    @IBOutlet weak var lblJogo: UILabel!
    
    var textoApoio:String = ""
    var imagemApoio:UIImage? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblJogo.text = textoApoio
        imgFigura.image = imagemApoio
        
        
    }
    
    
}

