//
//  ViewController.swift
//  Exemplo1TableView
//
//  Created by Usuário Convidado on 05/08/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    var animal = ["Urso", "Girafa","Rinoceronte","Leão", "Elefante"]
    var foto = ["urso", "girafa","rino","leao", "ele"]
    
    @IBOutlet weak var minhaTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        minhaTableView.dataSource = self
        minhaTableView.delegate = self
        // Do any additional setup after loading the view.
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return animal.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let celula = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)
        
        //celula.textLabel?.text = "Item número \(indexPath.row)"
        celula.textLabel?.text = animal[indexPath.row]
        celula.imageView?.image = UIImage(named: foto[indexPath.row])
        celula.detailTextLabel?.text = "Bla bla bla"
        celula.accessoryType = .detailButton
        return celula
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("Clique na célula funcionando")
    }
}

